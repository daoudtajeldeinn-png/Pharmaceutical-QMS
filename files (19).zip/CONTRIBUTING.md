# Contributing to Pharmaceutical QMS

Thank you for your interest in contributing to the Pharmaceutical QMS project! This document provides guidelines and workflows for contributing.

## Code of Conduct

### Our Pledge
We are committed to providing a welcoming and inclusive experience for everyone. We pledge to:
- Use welcoming and inclusive language
- Respect differing viewpoints and experiences
- Accept constructive criticism gracefully
- Focus on what's best for the community
- Show empathy towards other community members

### Standards
Examples of behavior that contributes to a positive environment:
- Being respectful of differing opinions and experiences
- Giving and gracefully accepting constructive feedback
- Focusing on what is best for the community
- Showing empathy towards other community members

Examples of unacceptable behavior:
- The use of sexualized language or imagery
- Trolling, insulting/derogatory comments, or personal attacks
- Public or private harassment
- Publishing others' private information without permission
- Other conduct which could reasonably be considered inappropriate

## How to Contribute

### Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates.

When creating a bug report, include:
- **Clear title** - Descriptive summary of the issue
- **Steps to reproduce** - Detailed steps to recreate the bug
- **Expected behavior** - What you expected to happen
- **Actual behavior** - What actually happened
- **Environment** - Browser, OS, version
- **Screenshots** - If applicable
- **Possible solution** - If you have suggestions

Use the bug report template when creating issues.

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion:
- **Use a clear and descriptive title**
- **Provide detailed description** of the suggested enhancement
- **Explain why** this enhancement would be useful
- **Provide examples** of how it would work
- **Consider compliance** - Note any regulatory considerations

Use the feature request template when creating issues.

### Pull Request Process

1. **Fork the repository** and create your branch from `main`
2. **Follow code standards** - See CODE_ORGANIZATION.md
3. **Write tests** - Include unit and integration tests
4. **Update documentation** - Keep docs in sync with code
5. **Run tests** - Ensure all tests pass
6. **Run linter** - Fix any linting issues
7. **Create PR** - Use the pull request template
8. **Address review feedback** - Make requested changes

#### Branch Naming Convention
```
feature/short-description
bugfix/short-description
hotfix/short-description
refactor/short-description
docs/short-description
```

Examples:
- `feature/electronic-signatures`
- `bugfix/audit-trail-timestamp`
- `hotfix/critical-security-issue`

#### Commit Message Format
```
type(scope): subject

body (optional)

footer (optional)
```

**Types:**
- `feat` - New feature
- `fix` - Bug fix
- `docs` - Documentation changes
- `style` - Code style changes (formatting)
- `refactor` - Code refactoring
- `test` - Adding or updating tests
- `chore` - Maintenance tasks

**Examples:**
```
feat(documents): add electronic signature capture

Implement 21 CFR Part 11 compliant electronic signatures
with password authentication and audit trail.

Closes #123
```

```
fix(audit): correct timestamp format in audit trail

Fixed issue where timestamps were not being stored
in ISO 8601 format as required.

Fixes #456
```

### Development Workflow

#### 1. Setup Development Environment
```bash
# Clone repository
git clone https://github.com/daoudtajeldeinn-png/Pharmaceutical-QMS.git
cd Pharmaceutical-QMS

# Install dependencies
npm install

# Setup environment
cp .env.example .env
# Edit .env with your settings

# Start development server
npm run dev
```

#### 2. Create Feature Branch
```bash
git checkout -b feature/your-feature-name
```

#### 3. Make Changes
- Write code following style guidelines
- Add tests for new functionality
- Update documentation as needed
- Follow ALCOA+ principles for data handling

#### 4. Test Your Changes
```bash
# Run all tests
npm run test

# Run specific test file
npm run test -- path/to/test.spec.ts

# Check code coverage
npm run test:coverage

# Run linter
npm run lint

# Fix linting issues
npm run lint:fix
```

#### 5. Commit Changes
```bash
# Stage changes
git add .

# Commit with descriptive message
git commit -m "feat(module): description"
```

#### 6. Push and Create PR
```bash
# Push to your fork
git push origin feature/your-feature-name

# Go to GitHub and create Pull Request
```

#### 7. Code Review
- Address reviewer comments
- Make requested changes
- Push updates to the same branch
- Once approved, PR will be merged

## Code Style Guidelines

### TypeScript/JavaScript
- Use TypeScript strict mode
- Explicit return types for functions
- Use `const` for immutable variables
- Use meaningful variable names
- Follow naming conventions in CODE_ORGANIZATION.md
- Maximum line length: 100 characters
- Use 2 spaces for indentation

### Components
- One component per file
- Use functional components with hooks
- Destructure props
- Use TypeScript interfaces for props
- Keep components focused and small
- Extract reusable logic into custom hooks

### CSS
- Use CSS modules or styled components
- Follow BEM naming convention
- Mobile-first approach
- Use CSS variables for theming

### Comments
- Write self-documenting code
- Add comments for complex logic
- Use JSDoc for public functions
- Keep comments up-to-date

## Testing Standards

### Unit Tests
- Test individual functions and components
- Mock external dependencies
- Aim for >80% code coverage
- Use descriptive test names

Example:
```typescript
describe('DocumentService', () => {
  describe('getDocument', () => {
    it('should return document when it exists', async () => {
      // Test implementation
    });
    
    it('should throw NotFoundError when document does not exist', async () => {
      // Test implementation
    });
  });
});
```

### Integration Tests
- Test module interactions
- Test workflows end-to-end
- Use realistic test data
- Test error scenarios

### E2E Tests
- Test critical user flows
- Test from user perspective
- Use Cypress or similar tool
- Run in CI/CD pipeline

## Documentation Standards

### Code Documentation
- Use JSDoc comments for public APIs
- Include parameter descriptions
- Include return value descriptions
- Provide usage examples

### Module Documentation
- Each module needs README.md
- Explain module purpose
- Provide usage examples
- Document public APIs
- Note compliance considerations

### User Documentation
- Keep user guides up-to-date
- Include screenshots
- Provide step-by-step instructions
- Address common issues

## Compliance Considerations

### When Making Changes
Always consider:
- **21 CFR Part 11** - Electronic records/signatures
- **ALCOA+** - Data integrity principles
- **GMP** - Good manufacturing practices
- **Audit Trail** - Log all significant actions
- **Validation** - Changes may require revalidation

### Critical Features
These features require QA review:
- Electronic signatures
- Audit trail
- User authentication
- Access control
- Data integrity checks
- Regulatory reports

## Review Process

### Code Review Checklist
Reviewers should verify:
- [ ] Code follows style guidelines
- [ ] Tests are included and passing
- [ ] Documentation is updated
- [ ] No security vulnerabilities
- [ ] Compliance requirements met
- [ ] Performance is acceptable
- [ ] No breaking changes (or documented)
- [ ] Accessibility standards met

### Compliance Review Checklist
For GMP-critical features:
- [ ] Data integrity maintained (ALCOA+)
- [ ] Audit trail properly implemented
- [ ] Access controls appropriate
- [ ] Electronic signatures valid
- [ ] Validation impact assessed
- [ ] User documentation updated
- [ ] Training materials updated

## Getting Help

### Resources
- **Documentation**: [docs/](docs/)
- **API Reference**: [docs/api/](docs/api/)
- **Examples**: [examples/](examples/)
- **Discussions**: [GitHub Discussions](https://github.com/daoudtajeldeinn-png/Pharmaceutical-QMS/discussions)

### Communication Channels
- **Issues**: For bugs and feature requests
- **Discussions**: For questions and ideas
- **Email**: For private matters

### Questions?
If you have questions:
1. Check existing documentation
2. Search closed issues
3. Ask in GitHub Discussions
4. Create a new issue

## Recognition

Contributors are recognized in:
- README.md contributors section
- Release notes for major contributions
- Annual contributor highlights

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

## Additional Notes

### First-Time Contributors
- Look for issues labeled `good first issue`
- Start with documentation improvements
- Ask questions if anything is unclear
- Don't be afraid to make mistakes

### Quality Over Quantity
- One well-tested feature is better than many buggy ones
- Take time to understand existing code
- Follow existing patterns and conventions
- Ask for help when needed

### Continuous Improvement
- We're always improving our processes
- Suggest improvements to this guide
- Share your experiences
- Help others get started

---

**Thank you for contributing to making pharmaceutical quality management better!**
