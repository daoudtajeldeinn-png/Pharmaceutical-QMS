# 📂 Pharmaceutical QMS - Project Structure Reorganization

## Current Issues to Address

1. ❌ Mixed language folder names (English + Arabic)
2. ❌ Flat structure without clear module separation
3. ❌ No clear separation of concerns
4. ❌ node_modules tracked in repository
5. ❌ Missing important organizational folders

## Recommended New Structure

```
Pharmaceutical-QMS/
│
├── .github/                          # GitHub specific files
│   ├── workflows/                    # CI/CD workflows
│   │   ├── ci.yml                   # Continuous Integration
│   │   ├── deploy.yml               # Deployment workflow
│   │   └── tests.yml                # Automated testing
│   ├── ISSUE_TEMPLATE/              # Issue templates
│   │   ├── bug_report.md
│   │   ├── feature_request.md
│   │   └── quality_event.md
│   └── PULL_REQUEST_TEMPLATE.md     # PR template
│
├── app/                              # Application source code
│   ├── core/                        # Core application modules
│   │   ├── auth/                    # Authentication & Authorization
│   │   │   ├── services/
│   │   │   ├── guards/
│   │   │   └── models/
│   │   ├── database/                # Database utilities
│   │   │   ├── indexeddb/
│   │   │   ├── migrations/
│   │   │   └── schemas/
│   │   └── config/                  # Application configuration
│   │       ├── app.config.ts
│   │       ├── routes.config.ts
│   │       └── validation.config.ts
│   │
│   ├── modules/                     # Feature modules
│   │   ├── documents/               # Document Management
│   │   │   ├── components/
│   │   │   ├── services/
│   │   │   ├── models/
│   │   │   ├── validators/
│   │   │   └── index.ts
│   │   │
│   │   ├── quality-events/          # CAPA, Deviations, Change Control
│   │   │   ├── capa/
│   │   │   ├── deviations/
│   │   │   ├── change-control/
│   │   │   └── index.ts
│   │   │
│   │   ├── audits/                  # Audit Management
│   │   │   ├── internal-audits/
│   │   │   ├── external-audits/
│   │   │   ├── audit-findings/
│   │   │   └── index.ts
│   │   │
│   │   ├── sops/                    # Standard Operating Procedures
│   │   │   ├── components/
│   │   │   ├── services/
│   │   │   ├── models/
│   │   │   └── index.ts
│   │   │
│   │   ├── training/                # Training Management
│   │   │   ├── courses/
│   │   │   ├── assessments/
│   │   │   ├── certifications/
│   │   │   └── index.ts
│   │   │
│   │   ├── batch-records/           # Manufacturing Batch Records
│   │   │   ├── components/
│   │   │   ├── services/
│   │   │   ├── models/
│   │   │   └── index.ts
│   │   │
│   │   ├── materials/               # Material Management
│   │   │   ├── raw-materials/
│   │   │   ├── intermediates/
│   │   │   ├── finished-goods/
│   │   │   └── index.ts
│   │   │
│   │   ├── laboratory/              # Laboratory Management
│   │   │   ├── test-methods/
│   │   │   ├── specifications/
│   │   │   ├── results/
│   │   │   └── index.ts
│   │   │
│   │   ├── compliance/              # Regulatory Compliance
│   │   │   ├── regulations/
│   │   │   ├── inspections/
│   │   │   ├── submissions/
│   │   │   └── index.ts
│   │   │
│   │   ├── risk-management/         # Risk Assessment & Management
│   │   │   ├── components/
│   │   │   ├── services/
│   │   │   ├── models/
│   │   │   └── index.ts
│   │   │
│   │   ├── analytics/               # Analytics & Reporting
│   │   │   ├── dashboards/
│   │   │   ├── reports/
│   │   │   ├── kpis/
│   │   │   └── index.ts
│   │   │
│   │   └── settings/                # System Settings
│   │       ├── user-management/
│   │       ├── roles-permissions/
│   │       ├── system-config/
│   │       └── index.ts
│   │
│   ├── shared/                      # Shared resources
│   │   ├── components/              # Reusable UI components
│   │   │   ├── buttons/
│   │   │   ├── forms/
│   │   │   ├── tables/
│   │   │   ├── modals/
│   │   │   ├── notifications/
│   │   │   └── layout/
│   │   │
│   │   ├── services/                # Shared services
│   │   │   ├── api.service.ts
│   │   │   ├── notification.service.ts
│   │   │   ├── logger.service.ts
│   │   │   └── validation.service.ts
│   │   │
│   │   ├── models/                  # Shared data models
│   │   │   ├── user.model.ts
│   │   │   ├── audit-trail.model.ts
│   │   │   └── common.models.ts
│   │   │
│   │   ├── utils/                   # Utility functions
│   │   │   ├── date.utils.ts
│   │   │   ├── string.utils.ts
│   │   │   ├── validation.utils.ts
│   │   │   └── export.utils.ts
│   │   │
│   │   ├── constants/               # Application constants
│   │   │   ├── routes.constants.ts
│   │   │   ├── status.constants.ts
│   │   │   └── roles.constants.ts
│   │   │
│   │   ├── types/                   # TypeScript type definitions
│   │   │   ├── api.types.ts
│   │   │   ├── models.types.ts
│   │   │   └── components.types.ts
│   │   │
│   │   └── guards/                  # Route and access guards
│   │       ├── auth.guard.ts
│   │       ├── role.guard.ts
│   │       └── permission.guard.ts
│   │
│   ├── styles/                      # Global styles
│   │   ├── base/
│   │   │   ├── _reset.css
│   │   │   ├── _typography.css
│   │   │   └── _variables.css
│   │   ├── components/
│   │   ├── layouts/
│   │   ├── themes/
│   │   └── main.css
│   │
│   ├── app.ts                       # Main application file
│   └── router.ts                    # Application router
│
├── assets/                          # Static assets
│   ├── images/
│   │   ├── logos/
│   │   ├── icons/
│   │   ├── illustrations/
│   │   └── backgrounds/
│   ├── fonts/
│   │   ├── inter/
│   │   └── roboto/
│   └── data/                        # Static data files
│       ├── regulations.json
│       ├── countries.json
│       └── templates/
│
├── public/                          # Public static files
│   ├── favicon.ico
│   ├── manifest.json
│   ├── robots.txt
│   └── service-worker.js
│
├── tests/                           # Test files
│   ├── unit/                        # Unit tests
│   │   ├── components/
│   │   ├── services/
│   │   └── utils/
│   ├── integration/                 # Integration tests
│   │   ├── modules/
│   │   └── workflows/
│   ├── e2e/                         # End-to-end tests
│   │   ├── specs/
│   │   └── fixtures/
│   ├── mocks/                       # Test mocks
│   │   ├── data/
│   │   └── services/
│   └── setup/                       # Test configuration
│       ├── jest.config.js
│       └── test-utils.ts
│
├── docs/                            # Documentation
│   ├── api/                         # API documentation
│   │   ├── endpoints.md
│   │   ├── authentication.md
│   │   └── data-models.md
│   ├── user-guide/                  # User documentation
│   │   ├── getting-started.md
│   │   ├── modules/
│   │   └── faq.md
│   ├── technical/                   # Technical documentation
│   │   ├── architecture.md
│   │   ├── database-schema.md
│   │   ├── security.md
│   │   └── deployment.md
│   ├── compliance/                  # Compliance documentation
│   │   ├── 21-cfr-part-11.md
│   │   ├── eu-gmp.md
│   │   ├── data-integrity.md
│   │   └── validation.md
│   └── development/                 # Developer documentation
│       ├── setup.md
│       ├── coding-standards.md
│       └── contributing.md
│
├── scripts/                         # Build and utility scripts
│   ├── build.js
│   ├── deploy.js
│   ├── seed-data.js
│   └── migrate.js
│
├── config/                          # Configuration files
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── eslint.config.js
│   └── prettier.config.js
│
├── .vscode/                         # VS Code settings
│   ├── settings.json
│   ├── extensions.json
│   └── launch.json
│
├── .husky/                          # Git hooks
│   ├── pre-commit
│   └── pre-push
│
├── .env.example                     # Environment variables template
├── .gitignore                       # Git ignore rules
├── .eslintrc.json                   # ESLint configuration
├── .prettierrc                      # Prettier configuration
├── package.json                     # Dependencies
├── package-lock.json                # Locked dependencies
├── tsconfig.json                    # TypeScript configuration
├── vite.config.ts                   # Vite configuration
├── README.md                        # Project documentation
├── CHANGELOG.md                     # Version history
├── CONTRIBUTING.md                  # Contribution guidelines
├── LICENSE                          # License file
└── ROADMAP.md                       # Project roadmap
```

## Migration Steps

### Step 1: Backup Current Structure
```bash
git checkout -b backup-original
git commit -m "Backup original structure"
git checkout main
```

### Step 2: Create New Structure
```bash
# Create main directories
mkdir -p app/{core,modules,shared,styles}
mkdir -p public tests/{unit,integration,e2e,mocks,setup}
mkdir -p docs/{api,user-guide,technical,compliance,development}
mkdir -p scripts config
```

### Step 3: Reorganize Existing Files
```bash
# Move existing app files to appropriate locations
# Example:
mv app/components app/shared/components
mv app/services app/shared/services
```

### Step 4: Update Imports
- Update all import paths to reflect new structure
- Use path aliases in tsconfig.json for cleaner imports

### Step 5: Update Configuration
- Update build configuration
- Update test configuration
- Update deployment scripts

### Step 6: Clean Up
```bash
# Remove old unnecessary files
rm -rf node_modules/.vite
echo "node_modules/" >> .gitignore
echo ".env" >> .gitignore
```

## Path Aliases Configuration

Add to `tsconfig.json`:
```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@app/*": ["app/*"],
      "@core/*": ["app/core/*"],
      "@modules/*": ["app/modules/*"],
      "@shared/*": ["app/shared/*"],
      "@assets/*": ["assets/*"],
      "@tests/*": ["tests/*"],
      "@docs/*": ["docs/*"]
    }
  }
}
```

## Benefits of New Structure

### ✅ Clear Separation of Concerns
- Core functionality isolated
- Feature modules independent
- Shared resources centralized

### ✅ Scalability
- Easy to add new modules
- Clear patterns to follow
- Minimal file conflicts

### ✅ Maintainability
- Easy to locate files
- Consistent organization
- Clear dependencies

### ✅ Collaboration
- Reduced merge conflicts
- Clear ownership boundaries
- Easy onboarding

### ✅ Testing
- Test files mirror source structure
- Easy to locate test files
- Clear test organization

### ✅ Documentation
- Comprehensive documentation structure
- Easy to maintain
- Multiple audience support

## Next Steps

1. **Review this structure** with your team
2. **Create migration plan** with timeline
3. **Set up branch protection** rules
4. **Create issues** for each migration task
5. **Update CI/CD** pipelines
6. **Train team** on new structure

## Additional Recommendations

### Naming Conventions
- Use kebab-case for folders: `quality-events`
- Use PascalCase for components: `DocumentViewer.tsx`
- Use camelCase for files: `documentService.ts`
- Use UPPER_CASE for constants: `API_ENDPOINTS.ts`

### Module Standards
Each module should contain:
- `index.ts` - Module barrel export
- `components/` - UI components
- `services/` - Business logic
- `models/` - Data models
- `validators/` - Validation logic
- `tests/` - Module tests
- `README.md` - Module documentation

### File Size Guidelines
- Components: < 300 lines
- Services: < 500 lines
- Models: < 200 lines
- Utils: < 150 lines

If files exceed these limits, consider splitting them.
