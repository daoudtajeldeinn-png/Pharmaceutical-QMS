# 💊 Pharmaceutical Quality Management System (QMS)

A comprehensive web-based Quality Management System designed specifically for pharmaceutical manufacturing and compliance operations.

[![Live Demo](https://img.shields.io/badge/demo-live-success)](https://daoudtajeldeinn-png.github.io/Pharmaceutical-QMS/)
[![TypeScript](https://img.shields.io/badge/TypeScript-81.9%25-blue)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

## 🎯 Overview

This QMS application provides pharmaceutical organizations with tools to manage quality processes, documentation, compliance tracking, and regulatory requirements in accordance with GMP (Good Manufacturing Practice) standards.

## ✨ Key Features

### Quality Management
- 📋 **Document Control** - Version control, approval workflows, and document lifecycle management
- 🔍 **Quality Events** - CAPA (Corrective and Preventive Actions), Deviations, and Change Control
- 📊 **Audit Management** - Internal and external audit planning, execution, and follow-up
- ⚠️ **Risk Management** - Risk assessments, FMEA, and mitigation strategies

### Compliance & Regulatory
- ✅ **GMP Compliance** - Track compliance with FDA 21 CFR Part 211, EU GMP Annex 1, and ICH guidelines
- 📝 **SOP Management** - Standard Operating Procedures creation, review, and training tracking
- 🔐 **Electronic Signatures** - 21 CFR Part 11 compliant electronic signature capture
- 📈 **Regulatory Reporting** - Generate reports for regulatory inspections

### Operations
- 🏭 **Batch Records** - Electronic batch manufacturing records with real-time tracking
- 📦 **Material Management** - Raw materials, intermediates, and finished goods tracking
- 🧪 **Laboratory Management** - Test methods, specifications, and results tracking
- 👥 **Training Management** - Employee training records and qualification tracking

### Analytics & Reporting
- 📊 **KPI Dashboard** - Real-time quality metrics and performance indicators
- 📈 **Trend Analysis** - Statistical process control and trending
- 📄 **Custom Reports** - Configurable reporting engine
- 📉 **Quality Metrics** - OOS, OOT, OOE tracking and analysis

## 🚀 Getting Started

### Prerequisites

```bash
Node.js >= 18.0.0
npm >= 9.0.0
```

### Installation

1. Clone the repository
```bash
git clone https://github.com/daoudtajeldeinn-png/Pharmaceutical-QMS.git
cd Pharmaceutical-QMS
```

2. Install dependencies
```bash
npm install
```

3. Configure environment
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. Start development server
```bash
npm run dev
```

5. Build for production
```bash
npm run build
```

## 📁 Project Structure

```
Pharmaceutical-QMS/
├── app/                    # Application source code
│   ├── components/         # Reusable UI components
│   ├── modules/           # Feature modules
│   │   ├── documents/     # Document management
│   │   ├── quality/       # Quality events (CAPA, Deviations)
│   │   ├── audits/        # Audit management
│   │   ├── sops/          # SOP management
│   │   ├── training/      # Training management
│   │   └── analytics/     # Reports and dashboards
│   ├── services/          # API and business logic
│   ├── models/            # Data models and types
│   ├── utils/             # Helper functions
│   └── config/            # App configuration
├── assets/                 # Static assets
│   ├── images/
│   ├── styles/
│   └── fonts/
├── icons/                  # Icon library
├── tests/                  # Test files
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── docs/                   # Documentation
│   ├── api/               # API documentation
│   ├── user-guide/        # User manuals
│   └── technical/         # Technical specifications
├── scripts/               # Build and deployment scripts
├── config.js              # Configuration file
├── main.js                # Application entry point
├── index.html             # Main HTML file
├── manifest.json          # PWA manifest
└── package.json           # Dependencies and scripts
```

## 🛠️ Technology Stack

### Frontend
- **TypeScript** - Type-safe development
- **Modern JavaScript** - ES2022+ features
- **Vite** - Build tool and dev server
- **CSS3** - Styling and animations

### Data Management
- **IndexedDB** - Local data persistence
- **LocalStorage** - Configuration and preferences

### Quality & Testing
- **ESLint** - Code quality
- **Jest** - Unit testing
- **Cypress** - E2E testing
- **Prettier** - Code formatting

## 📖 Documentation

- [User Guide](docs/user-guide/README.md) - End-user documentation
- [API Documentation](docs/api/README.md) - Developer API reference
- [Technical Specs](docs/technical/README.md) - Architecture and design
- [Compliance Guide](docs/compliance/README.md) - Regulatory compliance information

## 🔐 Security & Compliance

This system is designed with pharmaceutical compliance in mind:

- ✅ 21 CFR Part 11 compliance for electronic records
- ✅ Data integrity (ALCOA+ principles)
- ✅ Audit trail for all critical operations
- ✅ Role-based access control (RBAC)
- ✅ Secure authentication and authorization
- ✅ Encrypted data storage
- ✅ Validation documentation support

## 🧪 Testing

```bash
# Run unit tests
npm run test

# Run integration tests
npm run test:integration

# Run E2E tests
npm run test:e2e

# Generate coverage report
npm run test:coverage
```

## 📦 Deployment

### Production Build
```bash
npm run build
```

### Docker Deployment
```bash
docker build -t pharma-qms .
docker run -p 8080:80 pharma-qms
```

### GitHub Pages (Current)
The application is automatically deployed to GitHub Pages on push to main branch.

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 Changelog

See [CHANGELOG.md](CHANGELOG.md) for a list of changes and version history.

## 👥 Contributors

Thanks to all contributors who have helped build this project!

- [@daoudtajeldeinn-png](https://github.com/daoudtajeldeinn-png) - Project Lead
- [View all contributors](https://github.com/daoudtajeldeinn-png/Pharmaceutical-QMS/graphs/contributors)

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- 📧 Email: [support@pharma-qms.com](mailto:support@pharma-qms.com)
- 💬 Discussions: [GitHub Discussions](https://github.com/daoudtajeldeinn-png/Pharmaceutical-QMS/discussions)
- 🐛 Issues: [GitHub Issues](https://github.com/daoudtajeldeinn-png/Pharmaceutical-QMS/issues)

## 🗺️ Roadmap

### Q1 2026
- [ ] Mobile app (iOS/Android)
- [ ] Advanced analytics dashboard
- [ ] Integration with ERP systems

### Q2 2026
- [ ] AI-powered document review
- [ ] Predictive quality analytics
- [ ] Multi-language support

### Q3 2026
- [ ] Cloud deployment options
- [ ] Advanced workflow automation
- [ ] Supplier quality management

See the [full roadmap](ROADMAP.md) for more details.

## 🙏 Acknowledgments

- Pharmaceutical regulatory guidance from FDA, EMA, and ICH
- Open-source community for excellent tools and libraries
- QA professionals who provided valuable feedback

---

**Built with ❤️ for pharmaceutical quality professionals**
