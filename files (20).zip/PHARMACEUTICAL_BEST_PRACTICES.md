# 🏥 Pharmaceutical QMS - Best Practices & Compliance Guide

## Regulatory Framework Overview

### Key Regulations

#### United States (FDA)
- **21 CFR Part 11** - Electronic Records & Electronic Signatures
- **21 CFR Part 210** - Current Good Manufacturing Practice (CGMP)
- **21 CFR Part 211** - CGMP for Finished Pharmaceuticals
- **21 CFR Part 820** - Quality System Regulation (Medical Devices)

#### European Union (EMA)
- **EU GMP Guidelines** - Good Manufacturing Practice
- **Annex 1** - Manufacture of Sterile Medicinal Products
- **Annex 11** - Computerised Systems
- **EU GMP Chapter 4** - Documentation

#### International (ICH)
- **ICH Q7** - Good Manufacturing Practice for Active Pharmaceutical Ingredients
- **ICH Q8** - Pharmaceutical Development
- **ICH Q9** - Quality Risk Management
- **ICH Q10** - Pharmaceutical Quality System

### Compliance Principles

#### ALCOA+ Principles (Data Integrity)
```
A - Attributable    (Who did it?)
L - Legible         (Can it be read?)
C - Contemporaneous (Was it done in real-time?)
O - Original        (Is it the first record?)
A - Accurate        (Is it correct?)

+ (Plus):
C - Complete        (Is all data present?)
C - Consistent      (Is it logical?)
E - Enduring        (Will it last?)
A - Available       (Can it be retrieved?)
```

## System Architecture for Compliance

### 21 CFR Part 11 Requirements

#### Electronic Signatures
```typescript
// Electronic Signature Model
interface ElectronicSignature {
  // Identification
  signerId: string;              // Unique user ID
  signerName: string;            // Full name
  signerRole: string;            // Job title/role
  
  // Authentication
  authenticationMethod: 'password' | 'biometric' | 'token' | 'mfa';
  authenticationDate: Date;
  
  // Signature Details
  signatureDate: Date;
  signatureTime: string;         // Precise timestamp
  signatureMeaning: string;      // What the signature represents
  
  // Context
  documentId: string;
  documentVersion: string;
  actionType: 'created' | 'reviewed' | 'approved' | 'rejected';
  
  // Integrity
  checksum: string;              // Document hash at time of signing
  ipAddress: string;
  userAgent: string;
  
  // Audit
  auditTrailEntry: string;       // Link to audit trail
}

// Implementation Example
class ElectronicSignatureService {
  async captureSignature(
    userId: string,
    documentId: string,
    password: string,
    meaning: string
  ): Promise<ElectronicSignature> {
    // Verify user credentials
    const user = await this.authenticateUser(userId, password);
    
    // Get document current state
    const document = await this.getDocument(documentId);
    
    // Create signature
    const signature: ElectronicSignature = {
      signerId: user.id,
      signerName: `${user.firstName} ${user.lastName}`,
      signerRole: user.role,
      authenticationMethod: 'password',
      authenticationDate: new Date(),
      signatureDate: new Date(),
      signatureTime: new Date().toISOString(),
      signatureMeaning: meaning,
      documentId: document.id,
      documentVersion: document.version,
      actionType: this.determineAction(meaning),
      checksum: this.calculateChecksum(document),
      ipAddress: this.getClientIP(),
      userAgent: this.getUserAgent(),
      auditTrailEntry: await this.createAuditEntry(user, document, meaning),
    };
    
    // Store signature
    await this.storeSignature(signature);
    
    // Link to document
    await this.linkSignatureToDocument(signature, document);
    
    return signature;
  }
  
  private calculateChecksum(document: Document): string {
    // Use SHA-256 for document hash
    const content = JSON.stringify({
      id: document.id,
      version: document.version,
      content: document.content,
      metadata: document.metadata,
    });
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(content))
      .then(hash => Array.from(new Uint8Array(hash))
        .map(b => b.toString(16).padStart(2, '0'))
        .join(''));
  }
}
```

#### Audit Trail Requirements
```typescript
// Comprehensive Audit Trail Model
interface AuditTrailEntry {
  // Entry Identification
  id: string;
  timestamp: Date;
  
  // User Information
  userId: string;
  userName: string;
  userRole: string;
  
  // Action Details
  action: AuditAction;
  actionDescription: string;
  
  // Entity Information
  entityType: string;            // 'document', 'batch', 'sop', etc.
  entityId: string;
  entityName: string;
  
  // Change Details
  beforeValue?: any;             // State before change
  afterValue?: any;              // State after change
  changes: ChangeDetail[];
  
  // Context
  module: string;                // Which system module
  ipAddress: string;
  userAgent: string;
  sessionId: string;
  
  // Compliance
  reason?: string;               // Reason for change (if required)
  regulatorySignificance: boolean;
  gmpRelevant: boolean;
}

type AuditAction = 
  | 'create'
  | 'read'
  | 'update'
  | 'delete'
  | 'approve'
  | 'reject'
  | 'sign'
  | 'export'
  | 'print'
  | 'archive';

interface ChangeDetail {
  field: string;
  oldValue: any;
  newValue: any;
  changeType: 'added' | 'modified' | 'removed';
}

// Audit Trail Service
class AuditTrailService {
  async logAction(
    action: AuditAction,
    entityType: string,
    entityId: string,
    changes?: ChangeDetail[],
    reason?: string
  ): Promise<AuditTrailEntry> {
    const entry: AuditTrailEntry = {
      id: this.generateId(),
      timestamp: new Date(),
      userId: this.getCurrentUser().id,
      userName: this.getCurrentUser().fullName,
      userRole: this.getCurrentUser().role,
      action,
      actionDescription: this.getActionDescription(action),
      entityType,
      entityId,
      entityName: await this.getEntityName(entityType, entityId),
      changes: changes || [],
      module: this.getCurrentModule(),
      ipAddress: this.getClientIP(),
      userAgent: this.getUserAgent(),
      sessionId: this.getSessionId(),
      reason,
      regulatorySignificance: this.isRegulatorySignificant(entityType, action),
      gmpRelevant: this.isGMPRelevant(entityType),
    };
    
    // Store immutably
    await this.storeAuditEntry(entry);
    
    // Alert if regulatory significant
    if (entry.regulatorySignificance) {
      await this.notifyQualityAssurance(entry);
    }
    
    return entry;
  }
  
  // Audit trail must be immutable
  private async storeAuditEntry(entry: AuditTrailEntry): Promise<void> {
    // Store with write-once protection
    await db.auditTrail.add(entry);
    
    // Also store encrypted backup
    const encrypted = await this.encrypt(entry);
    await this.backupStorage.store(entry.id, encrypted);
  }
}
```

### Data Integrity Controls

#### Version Control
```typescript
interface DocumentVersion {
  // Version Information
  versionNumber: string;         // e.g., "1.0", "2.3"
  majorVersion: number;
  minorVersion: number;
  
  // Lifecycle
  status: 'draft' | 'in_review' | 'approved' | 'effective' | 'obsolete';
  createdDate: Date;
  effectiveDate?: Date;
  expiryDate?: Date;
  supersededDate?: Date;
  
  // Content
  content: string;
  checksum: string;              // SHA-256 hash
  
  // Approval Chain
  author: string;
  reviewers: Reviewer[];
  approvers: Approver[];
  
  // Compliance
  changeReason: string;          // Why this version was created
  impactAssessment?: string;     // Impact of changes
  trainingRequired: boolean;
  
  // References
  previousVersion?: string;
  nextVersion?: string;
  relatedDocuments: string[];
}

class VersionControlService {
  async createNewVersion(
    documentId: string,
    changeReason: string,
    impactAssessment: string
  ): Promise<DocumentVersion> {
    // Get current version
    const current = await this.getCurrentVersion(documentId);
    
    // Calculate new version number
    const newVersionNumber = this.calculateNewVersion(
      current.versionNumber,
      this.assessChangeImpact(changeReason)
    );
    
    // Create new version
    const newVersion: DocumentVersion = {
      versionNumber: newVersionNumber,
      majorVersion: parseInt(newVersionNumber.split('.')[0]),
      minorVersion: parseInt(newVersionNumber.split('.')[1]),
      status: 'draft',
      createdDate: new Date(),
      content: current.content, // Start with current content
      checksum: await this.calculateChecksum(current.content),
      author: this.getCurrentUser().id,
      reviewers: [],
      approvers: [],
      changeReason,
      impactAssessment,
      trainingRequired: this.requiresTraining(changeReason),
      previousVersion: current.versionNumber,
    };
    
    // Store version
    await this.storeVersion(documentId, newVersion);
    
    // Log audit trail
    await this.auditLog({
      action: 'version_created',
      entity: documentId,
      details: { version: newVersionNumber, reason: changeReason },
    });
    
    return newVersion;
  }
}
```

#### Access Control (RBAC)
```typescript
// Role-Based Access Control
enum Role {
  ADMIN = 'admin',
  QUALITY_MANAGER = 'quality_manager',
  QA_SPECIALIST = 'qa_specialist',
  PRODUCTION_MANAGER = 'production_manager',
  OPERATOR = 'operator',
  VIEWER = 'viewer',
}

enum Permission {
  // Document Permissions
  DOCUMENT_CREATE = 'document:create',
  DOCUMENT_READ = 'document:read',
  DOCUMENT_UPDATE = 'document:update',
  DOCUMENT_DELETE = 'document:delete',
  DOCUMENT_APPROVE = 'document:approve',
  
  // Quality Event Permissions
  CAPA_CREATE = 'capa:create',
  CAPA_INVESTIGATE = 'capa:investigate',
  CAPA_APPROVE = 'capa:approve',
  DEVIATION_REPORT = 'deviation:report',
  DEVIATION_INVESTIGATE = 'deviation:investigate',
  
  // Audit Permissions
  AUDIT_PLAN = 'audit:plan',
  AUDIT_EXECUTE = 'audit:execute',
  AUDIT_APPROVE = 'audit:approve',
  
  // System Permissions
  USER_MANAGE = 'user:manage',
  SYSTEM_CONFIG = 'system:config',
  AUDIT_VIEW = 'audit:view',
}

const RolePermissions: Record<Role, Permission[]> = {
  [Role.ADMIN]: [
    // All permissions
    ...Object.values(Permission),
  ],
  
  [Role.QUALITY_MANAGER]: [
    Permission.DOCUMENT_CREATE,
    Permission.DOCUMENT_READ,
    Permission.DOCUMENT_UPDATE,
    Permission.DOCUMENT_APPROVE,
    Permission.CAPA_CREATE,
    Permission.CAPA_INVESTIGATE,
    Permission.CAPA_APPROVE,
    Permission.DEVIATION_REPORT,
    Permission.DEVIATION_INVESTIGATE,
    Permission.AUDIT_PLAN,
    Permission.AUDIT_EXECUTE,
    Permission.AUDIT_APPROVE,
    Permission.AUDIT_VIEW,
  ],
  
  [Role.QA_SPECIALIST]: [
    Permission.DOCUMENT_CREATE,
    Permission.DOCUMENT_READ,
    Permission.DOCUMENT_UPDATE,
    Permission.CAPA_CREATE,
    Permission.CAPA_INVESTIGATE,
    Permission.DEVIATION_REPORT,
    Permission.DEVIATION_INVESTIGATE,
    Permission.AUDIT_EXECUTE,
  ],
  
  [Role.OPERATOR]: [
    Permission.DOCUMENT_READ,
    Permission.DEVIATION_REPORT,
  ],
  
  [Role.VIEWER]: [
    Permission.DOCUMENT_READ,
  ],
};

class AccessControlService {
  hasPermission(userId: string, permission: Permission): boolean {
    const user = this.getUser(userId);
    const userPermissions = RolePermissions[user.role];
    return userPermissions.includes(permission);
  }
  
  async checkAccess(
    userId: string,
    action: string,
    resourceType: string,
    resourceId: string
  ): Promise<boolean> {
    // Check basic permission
    const permission = `${resourceType}:${action}` as Permission;
    if (!this.hasPermission(userId, permission)) {
      return false;
    }
    
    // Check ownership or assignment
    const resource = await this.getResource(resourceType, resourceId);
    if (resource.owner === userId || resource.assignees?.includes(userId)) {
      return true;
    }
    
    // Check department access
    const user = this.getUser(userId);
    if (resource.department === user.department) {
      return true;
    }
    
    return false;
  }
}
```

## Quality Management Processes

### CAPA (Corrective and Preventive Action)

```typescript
interface CAPA {
  // Identification
  id: string;
  capaNumber: string;            // e.g., "CAPA-2026-001"
  title: string;
  
  // Type
  type: 'corrective' | 'preventive';
  source: 'deviation' | 'audit' | 'complaint' | 'review' | 'other';
  
  // Problem Description
  description: string;
  immediateAction: string;
  impactAssessment: {
    productQuality: 'none' | 'low' | 'medium' | 'high' | 'critical';
    patientSafety: 'none' | 'low' | 'medium' | 'high' | 'critical';
    compliance: 'none' | 'low' | 'medium' | 'high' | 'critical';
  };
  
  // Investigation
  rootCauseAnalysis: {
    method: '5-whys' | 'fishbone' | 'fault-tree' | 'other';
    findings: string;
    rootCause: string;
  };
  
  // Actions
  correctiveActions: Action[];
  preventiveActions: Action[];
  
  // Effectiveness
  effectivenessCheck: {
    planned: boolean;
    date?: Date;
    result?: 'effective' | 'partially-effective' | 'not-effective';
    evidence?: string;
  };
  
  // Lifecycle
  status: 'open' | 'investigation' | 'action' | 'verification' | 'closed';
  openedDate: Date;
  targetClosureDate: Date;
  actualClosureDate?: Date;
  
  // Responsibility
  owner: string;
  qaApprover: string;
  
  // Compliance
  gmpRelevant: boolean;
  regulatoryReporting: boolean;
}

interface Action {
  id: string;
  description: string;
  responsible: string;
  dueDate: Date;
  completedDate?: Date;
  status: 'planned' | 'in-progress' | 'completed' | 'verified';
  evidence?: string;
}
```

### Deviation Management

```typescript
interface Deviation {
  // Identification
  id: string;
  deviationNumber: string;       // e.g., "DEV-2026-001"
  title: string;
  
  // Classification
  type: 'manufacturing' | 'laboratory' | 'quality' | 'equipment' | 'documentation';
  severity: 'critical' | 'major' | 'minor';
  
  // Description
  description: string;
  occurredDate: Date;
  discoveredDate: Date;
  location: string;
  
  // Impact
  affectedProducts: string[];
  affectedBatches: string[];
  quantityImpacted: number;
  
  // Investigation
  immediateAction: string;
  investigationRequired: boolean;
  investigation?: {
    method: string;
    findings: string;
    rootCause: string;
    completedDate: Date;
  };
  
  // Disposition
  materialDisposition: 'release' | 'reprocess' | 'reject' | 'pending';
  justification: string;
  
  // Risk Assessment
  riskAssessment: {
    likelihood: 1 | 2 | 3 | 4 | 5;
    severity: 1 | 2 | 3 | 4 | 5;
    detectability: 1 | 2 | 3 | 4 | 5;
    riskPriorityNumber: number;  // likelihood × severity × detectability
  };
  
  // CAPA Required
  capaRequired: boolean;
  linkedCapa?: string;
  
  // Lifecycle
  status: 'reported' | 'investigation' | 'disposition' | 'qa-review' | 'closed';
  reportedBy: string;
  investigatedBy: string;
  approvedBy: string;
  
  // Compliance
  regulatoryReportable: boolean;
  reportedToAuthority?: boolean;
}
```

### Change Control

```typescript
interface ChangeControl {
  // Identification
  id: string;
  changeNumber: string;          // e.g., "CC-2026-001"
  title: string;
  
  // Request
  requestor: string;
  requestDate: Date;
  changeDescription: string;
  changeJustification: string;
  
  // Classification
  type: 'process' | 'equipment' | 'material' | 'facility' | 'document' | 'system';
  category: 'major' | 'minor';   // Based on validation impact
  
  // Impact Assessment
  impactAssessment: {
    product: string;
    process: string;
    equipment: string;
    documentation: string;
    validation: string;
    training: string;
  };
  
  // Risk Assessment
  riskAssessment: {
    beforeChange: {
      likelihood: number;
      severity: number;
      risk: number;
    };
    afterChange: {
      likelihood: number;
      severity: number;
      risk: number;
    };
    riskMitigation: string;
  };
  
  // Implementation
  implementationPlan: string;
  implementationDate?: Date;
  rollbackPlan: string;
  
  // Validation
  validationRequired: boolean;
  validationPlan?: string;
  validationStatus?: 'not-started' | 'in-progress' | 'completed';
  
  // Training
  trainingRequired: boolean;
  trainingCompleted?: boolean;
  
  // Approval Chain
  technicalReview: Approval;
  qualityReview: Approval;
  finalApproval: Approval;
  
  // Lifecycle
  status: 'requested' | 'review' | 'approved' | 'rejected' | 'implemented' | 'verified' | 'closed';
  
  // Effectiveness
  effectivenessCheck: {
    required: boolean;
    date?: Date;
    result?: string;
  };
}

interface Approval {
  reviewer: string;
  date?: Date;
  decision?: 'approved' | 'rejected' | 'conditional';
  comments?: string;
}
```

## Validation Requirements

### Computer System Validation (CSV)

```typescript
interface ValidationPlan {
  // Identification
  systemName: string;
  systemId: string;
  version: string;
  
  // Scope
  scope: string;
  objectives: string[];
  
  // Risk Assessment
  gxpClassification: 'GxP' | 'non-GxP';
  criticalityLevel: 'high' | 'medium' | 'low';
  
  // Validation Approach
  approach: 'prospective' | 'concurrent' | 'retrospective';
  validationType: 'full' | 'partial' | 'revalidation';
  
  // Test Strategy
  testLevels: {
    unitTesting: boolean;
    integrationTesting: boolean;
    systemTesting: boolean;
    userAcceptanceTesting: boolean;
  };
  
  // Documentation
  requiredDocuments: {
    userRequirementSpecification: boolean;
    functionalSpecification: boolean;
    designSpecification: boolean;
    traceabilityMatrix: boolean;
    testScripts: boolean;
    testResults: boolean;
    validationSummaryReport: boolean;
  };
  
  // Responsibilities
  validationTeam: {
    lead: string;
    members: string[];
    qaReviewer: string;
  };
  
  // Schedule
  plannedStart: Date;
  plannedCompletion: Date;
}

interface ValidationTestCase {
  id: string;
  requirementId: string;         // Traced to requirement
  category: 'IQ' | 'OQ' | 'PQ';  // Installation/Operational/Performance
  title: string;
  objective: string;
  preConditions: string[];
  testSteps: TestStep[];
  expectedResult: string;
  actualResult?: string;
  status: 'not-started' | 'in-progress' | 'passed' | 'failed' | 'blocked';
  executedBy?: string;
  executedDate?: Date;
  evidence?: string[];           // Screenshots, logs, etc.
}
```

## Reporting & Analytics

### Quality Metrics Dashboard

```typescript
interface QualityMetrics {
  period: {
    start: Date;
    end: Date;
  };
  
  // Process Metrics
  manufacturing: {
    batchesProduced: number;
    rightFirstTime: number;       // % of batches passed first time
    averageCycleTime: number;     // Days
  };
  
  // Quality Events
  deviations: {
    total: number;
    critical: number;
    major: number;
    minor: number;
    averageTimeToClose: number;   // Days
  };
  
  capas: {
    opened: number;
    closed: number;
    overdue: number;
    onTime: number;               // % closed by target date
    averageTimeToClose: number;
  };
  
  // Laboratory
  outOfSpecification: {
    count: number;
    rate: number;                 // Per 1000 tests
  };
  
  outOfTrend: {
    count: number;
    investigations: number;
  };
  
  // Audit
  audits: {
    internal: number;
    external: number;
    findings: {
      critical: number;
      major: number;
      minor: number;
    };
  };
  
  // Training
  training: {
    compliance: number;           // % of required training completed
    overdue: number;
  };
  
  // Trends
  trends: {
    improving: string[];
    declining: string[];
    stable: string[];
  };
}
```

## Implementation Checklist

### Phase 1: Foundation (Weeks 1-4)
- [ ] Set up user authentication
- [ ] Implement role-based access control
- [ ] Create audit trail framework
- [ ] Set up database with proper schemas
- [ ] Implement electronic signature capture
- [ ] Create document management core

### Phase 2: Quality Events (Weeks 5-8)
- [ ] Implement CAPA module
- [ ] Implement Deviation module
- [ ] Implement Change Control module
- [ ] Create workflow engine
- [ ] Add notification system

### Phase 3: Documentation (Weeks 9-12)
- [ ] Complete SOP management
- [ ] Add batch record templates
- [ ] Implement document approval workflows
- [ ] Add version control
- [ ] Create document search

### Phase 4: Training & Audits (Weeks 13-16)
- [ ] Training management module
- [ ] Training effectiveness tracking
- [ ] Audit planning and execution
- [ ] Finding management
- [ ] CAPA linkage

### Phase 5: Analytics & Reporting (Weeks 17-20)
- [ ] Quality metrics dashboard
- [ ] Trend analysis tools
- [ ] Custom report builder
- [ ] Data export functionality
- [ ] Regulatory report templates

### Phase 6: Validation (Weeks 21-24)
- [ ] Create validation documentation
- [ ] Execute validation test cases
- [ ] Document deviations
- [ ] Obtain QA approval
- [ ] Release to production

## Regulatory Inspection Readiness

### Inspection Preparation Checklist
- [ ] All SOPs current and approved
- [ ] Electronic signature logs available
- [ ] Audit trail reports ready
- [ ] Training records complete
- [ ] Validation documentation organized
- [ ] CAPA effectiveness checks completed
- [ ] Deviation investigations closed
- [ ] Change controls documented
- [ ] Self-inspection recent
- [ ] Management review current

### Common Inspection Findings to Avoid
1. Inadequate change control
2. Incomplete investigations
3. Training gaps
4. Audit trail deficiencies
5. Out-of-specification procedures inadequate
6. Equipment qualification incomplete
7. Contamination control issues
8. Data integrity concerns

## Continuous Improvement

### Quality Culture Principles
1. **Quality First** - Never compromise on quality
2. **Right First Time** - Prevent rather than detect
3. **Continuous Learning** - Learn from every event
4. **Transparency** - Open communication about issues
5. **Data-Driven** - Decisions based on data
6. **Risk-Based** - Focus resources on high risks
7. **Collaborative** - Cross-functional teamwork
8. **Compliant** - Regulatory compliance is non-negotiable

### Key Performance Indicators (KPIs)
- Right First Time Rate > 95%
- Deviation Rate < 1 per 100 batches
- CAPA On-Time Closure > 90%
- Training Compliance > 95%
- Audit Finding Closure < 30 days
- Customer Complaint Rate < 0.1%

---

**Remember: Quality cannot be tested into a product; it must be built in.**
