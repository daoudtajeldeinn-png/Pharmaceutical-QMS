# 💻 Code Organization & Best Practices Guide

## TypeScript Coding Standards

### File Organization

#### Component Structure
```typescript
// DocumentViewer.tsx

// 1. Imports (grouped and sorted)
import { useState, useEffect, useCallback } from 'react';
import type { Document, DocumentStatus } from '@shared/types';
import { documentService } from '@modules/documents/services';
import { Button, Card, Modal } from '@shared/components';
import './DocumentViewer.css';

// 2. Types & Interfaces
interface DocumentViewerProps {
  documentId: string;
  readonly?: boolean;
  onStatusChange?: (status: DocumentStatus) => void;
}

interface ViewerState {
  document: Document | null;
  loading: boolean;
  error: string | null;
}

// 3. Constants
const REFRESH_INTERVAL = 30000;
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

// 4. Component
export const DocumentViewer: React.FC<DocumentViewerProps> = ({
  documentId,
  readonly = false,
  onStatusChange,
}) => {
  // State
  const [state, setState] = useState<ViewerState>({
    document: null,
    loading: true,
    error: null,
  });

  // Effects
  useEffect(() => {
    loadDocument();
  }, [documentId]);

  // Handlers
  const loadDocument = useCallback(async () => {
    // Implementation
  }, [documentId]);

  // Render
  return (
    <div className="document-viewer">
      {/* JSX */}
    </div>
  );
};

// 5. Helper functions (if small and component-specific)
function formatDocumentName(name: string): string {
  return name.trim().replace(/\s+/g, '-').toLowerCase();
}
```

#### Service Structure
```typescript
// documentService.ts

// 1. Imports
import type { Document, CreateDocumentDTO, UpdateDocumentDTO } from '../models';
import { db } from '@core/database';
import { logger } from '@shared/services';
import { ValidationError, NotFoundError } from '@shared/errors';

// 2. Types
interface DocumentServiceConfig {
  enableCache?: boolean;
  cacheTimeout?: number;
}

// 3. Service Class
export class DocumentService {
  private config: DocumentServiceConfig;
  private cache: Map<string, Document> = new Map();

  constructor(config: DocumentServiceConfig = {}) {
    this.config = {
      enableCache: true,
      cacheTimeout: 300000, // 5 minutes
      ...config,
    };
  }

  // Public methods
  async getDocument(id: string): Promise<Document> {
    try {
      // Check cache first
      if (this.config.enableCache) {
        const cached = this.cache.get(id);
        if (cached) return cached;
      }

      // Fetch from database
      const document = await db.documents.get(id);
      
      if (!document) {
        throw new NotFoundError(`Document ${id} not found`);
      }

      // Update cache
      if (this.config.enableCache) {
        this.cache.set(id, document);
      }

      return document;
    } catch (error) {
      logger.error('Failed to get document', { id, error });
      throw error;
    }
  }

  async createDocument(data: CreateDocumentDTO): Promise<Document> {
    // Validate
    this.validateCreateData(data);

    // Create
    const document = await db.documents.add({
      ...data,
      createdAt: new Date(),
      status: 'draft',
    });

    // Log audit trail
    await this.logAuditTrail('create', document.id);

    return document;
  }

  // Private methods
  private validateCreateData(data: CreateDocumentDTO): void {
    if (!data.title || data.title.length < 3) {
      throw new ValidationError('Title must be at least 3 characters');
    }
    // More validations...
  }

  private async logAuditTrail(action: string, documentId: string): Promise<void> {
    await db.auditTrail.add({
      action,
      entityType: 'document',
      entityId: documentId,
      timestamp: new Date(),
    });
  }
}

// 4. Export singleton instance
export const documentService = new DocumentService();
```

#### Model Structure
```typescript
// document.model.ts

// 1. Enums
export enum DocumentStatus {
  DRAFT = 'draft',
  IN_REVIEW = 'in_review',
  APPROVED = 'approved',
  OBSOLETE = 'obsolete',
}

export enum DocumentType {
  SOP = 'sop',
  BATCH_RECORD = 'batch_record',
  PROTOCOL = 'protocol',
  REPORT = 'report',
}

// 2. Base interfaces
interface BaseEntity {
  id: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
}

interface AuditableEntity extends BaseEntity {
  version: number;
  auditTrail: AuditEntry[];
}

// 3. Main model
export interface Document extends AuditableEntity {
  // Identifiers
  documentNumber: string;
  title: string;
  type: DocumentType;
  
  // Status
  status: DocumentStatus;
  effectiveDate?: Date;
  expiryDate?: Date;
  
  // Content
  content: string;
  attachments: Attachment[];
  
  // Metadata
  department: string;
  owner: string;
  reviewers: string[];
  approvers: string[];
  
  // Compliance
  requiresTraining: boolean;
  gmpRelevant: boolean;
  regulatoryReferences: string[];
}

// 4. DTOs (Data Transfer Objects)
export interface CreateDocumentDTO {
  title: string;
  type: DocumentType;
  content: string;
  department: string;
  owner: string;
}

export interface UpdateDocumentDTO {
  title?: string;
  content?: string;
  status?: DocumentStatus;
}

// 5. Related types
interface Attachment {
  id: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  url: string;
  uploadedAt: Date;
  uploadedBy: string;
}

interface AuditEntry {
  timestamp: Date;
  user: string;
  action: string;
  changes: Record<string, any>;
}

// 6. Type guards
export function isDocument(obj: any): obj is Document {
  return (
    obj &&
    typeof obj.id === 'string' &&
    typeof obj.title === 'string' &&
    Object.values(DocumentStatus).includes(obj.status)
  );
}

// 7. Validators
export const DocumentValidators = {
  title: (title: string): boolean => {
    return title.length >= 3 && title.length <= 200;
  },
  
  documentNumber: (num: string): boolean => {
    return /^[A-Z]{2,4}-\d{4}$/.test(num);
  },
};
```

## Module Organization Pattern

### Each Module Should Follow This Structure:

```
modules/documents/
├── index.ts                    # Barrel export
├── README.md                   # Module documentation
├── components/                 # UI components
│   ├── DocumentList.tsx
│   ├── DocumentViewer.tsx
│   ├── DocumentEditor.tsx
│   └── index.ts               # Component barrel
├── services/                   # Business logic
│   ├── document.service.ts
│   ├── version.service.ts
│   └── index.ts
├── models/                     # Data models
│   ├── document.model.ts
│   ├── version.model.ts
│   └── index.ts
├── validators/                 # Validation logic
│   ├── document.validator.ts
│   └── index.ts
├── utils/                      # Module utilities
│   ├── document-utils.ts
│   └── index.ts
├── hooks/                      # React hooks
│   ├── useDocument.ts
│   ├── useDocumentList.ts
│   └── index.ts
├── constants/                  # Module constants
│   └── document.constants.ts
└── tests/                      # Module tests
    ├── document.service.test.ts
    ├── DocumentViewer.test.tsx
    └── mocks/
```

## Best Practices

### 1. Naming Conventions

#### Files
```typescript
// Components - PascalCase
DocumentViewer.tsx
QualityEventCard.tsx

// Services - camelCase with .service suffix
document.service.ts
audit.service.ts

// Models - camelCase with .model suffix
document.model.ts
user.model.ts

// Utilities - camelCase with .utils suffix
date.utils.ts
validation.utils.ts

// Constants - camelCase with .constants suffix
routes.constants.ts
status.constants.ts

// Types - camelCase with .types suffix
api.types.ts
models.types.ts
```

#### Variables & Functions
```typescript
// camelCase for variables and functions
const userDocument = getDocument();
function calculateRiskScore() {}

// PascalCase for classes and components
class DocumentService {}
const DocumentViewer = () => {};

// UPPER_SNAKE_CASE for constants
const MAX_FILE_SIZE = 10 * 1024 * 1024;
const API_BASE_URL = 'https://api.example.com';

// Prefixes
const isValid = true;        // Boolean: is, has, can, should
const hasPermission = false;
const canEdit = true;

const handleClick = () => {}; // Event handlers: handle
const onChange = () => {};

const useDocument = () => {}; // Hooks: use
const useFetch = () => {};
```

### 2. Import Organization

```typescript
// 1. External dependencies (alphabetically)
import { useState, useEffect } from 'react';
import { format } from 'date-fns';

// 2. Internal core modules
import { authService } from '@core/auth';
import { db } from '@core/database';

// 3. Internal feature modules
import { documentService } from '@modules/documents/services';

// 4. Shared resources
import { Button, Modal } from '@shared/components';
import { logger } from '@shared/services';
import { formatDate } from '@shared/utils';

// 5. Types
import type { Document, User } from '@shared/types';

// 6. Relative imports (avoid when possible)
import { LocalComponent } from './LocalComponent';

// 7. Styles
import './styles.css';
```

### 3. Error Handling

```typescript
// Custom error classes
export class ValidationError extends Error {
  constructor(
    message: string,
    public field?: string,
    public value?: any
  ) {
    super(message);
    this.name = 'ValidationError';
  }
}

export class NotFoundError extends Error {
  constructor(
    message: string,
    public entityType?: string,
    public entityId?: string
  ) {
    super(message);
    this.name = 'NotFoundError';
  }
}

// Usage in services
async getDocument(id: string): Promise<Document> {
  try {
    const document = await db.documents.get(id);
    
    if (!document) {
      throw new NotFoundError(
        `Document not found`,
        'document',
        id
      );
    }
    
    return document;
  } catch (error) {
    if (error instanceof NotFoundError) {
      logger.warn('Document not found', { id });
    } else {
      logger.error('Failed to get document', { id, error });
    }
    throw error;
  }
}

// Usage in components
try {
  const document = await documentService.getDocument(id);
  setDocument(document);
} catch (error) {
  if (error instanceof NotFoundError) {
    showNotification('Document not found', 'warning');
  } else if (error instanceof ValidationError) {
    showNotification(error.message, 'error');
  } else {
    showNotification('An unexpected error occurred', 'error');
    logger.error('Unexpected error', error);
  }
}
```

### 4. Async/Await Best Practices

```typescript
// ✅ Good: Proper error handling
async function loadData() {
  try {
    const data = await fetchData();
    return data;
  } catch (error) {
    logger.error('Failed to load data', error);
    throw error;
  }
}

// ✅ Good: Parallel execution when independent
async function loadMultiple() {
  const [documents, users, settings] = await Promise.all([
    documentService.getAll(),
    userService.getAll(),
    settingsService.get(),
  ]);
  
  return { documents, users, settings };
}

// ❌ Bad: Sequential execution when not needed
async function loadMultipleBad() {
  const documents = await documentService.getAll();
  const users = await userService.getAll();
  const settings = await settingsService.get();
  
  return { documents, users, settings };
}

// ✅ Good: Race conditions handled
async function loadWithTimeout() {
  const timeout = new Promise((_, reject) =>
    setTimeout(() => reject(new Error('Timeout')), 5000)
  );
  
  const data = await Promise.race([
    fetchData(),
    timeout
  ]);
  
  return data;
}
```

### 5. TypeScript Best Practices

```typescript
// ✅ Good: Explicit return types
function calculateTotal(items: Item[]): number {
  return items.reduce((sum, item) => sum + item.price, 0);
}

// ✅ Good: Use const assertions for immutable objects
const STATUS = {
  DRAFT: 'draft',
  APPROVED: 'approved',
} as const;

type Status = typeof STATUS[keyof typeof STATUS];

// ✅ Good: Use discriminated unions
type Result<T> =
  | { success: true; data: T }
  | { success: false; error: string };

function processResult<T>(result: Result<T>) {
  if (result.success) {
    // TypeScript knows result.data exists
    return result.data;
  } else {
    // TypeScript knows result.error exists
    throw new Error(result.error);
  }
}

// ✅ Good: Use utility types
type PartialDocument = Partial<Document>;
type ReadonlyDocument = Readonly<Document>;
type DocumentKeys = keyof Document;
type RequiredDocument = Required<Document>;

// ✅ Good: Generic constraints
function findById<T extends { id: string }>(
  items: T[],
  id: string
): T | undefined {
  return items.find(item => item.id === id);
}
```

### 6. Component Best Practices

```typescript
// ✅ Good: Destructure props
interface Props {
  title: string;
  onSave: () => void;
}

const Component: React.FC<Props> = ({ title, onSave }) => {
  // Implementation
};

// ✅ Good: Use custom hooks
function useDocument(id: string) {
  const [document, setDocument] = useState<Document | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const doc = await documentService.getDocument(id);
        if (!cancelled) {
          setDocument(doc);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err.message);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    load();

    return () => {
      cancelled = true;
    };
  }, [id]);

  return { document, loading, error };
}

// ✅ Good: Memoize expensive computations
const filteredDocuments = useMemo(() => {
  return documents.filter(doc =>
    doc.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
}, [documents, searchTerm]);

// ✅ Good: Memoize callbacks
const handleSave = useCallback(() => {
  documentService.save(document);
}, [document]);
```

### 7. Comments & Documentation

```typescript
/**
 * Retrieves a document by its ID.
 * 
 * @param id - The unique identifier of the document
 * @returns Promise resolving to the document
 * @throws {NotFoundError} If the document doesn't exist
 * @throws {PermissionError} If user lacks read permission
 * 
 * @example
 * ```typescript
 * const document = await getDocument('doc-123');
 * console.log(document.title);
 * ```
 */
async function getDocument(id: string): Promise<Document> {
  // Implementation
}

// Use comments for complex logic
function calculateRiskScore(factors: RiskFactor[]): number {
  // Risk score = Σ(severity × probability × detectability)
  // Scale: 1-10 for each factor
  // Total range: 0-1000
  return factors.reduce((score, factor) => {
    return score + (factor.severity * factor.probability * factor.detectability);
  }, 0);
}

// Document WHY, not WHAT
// ❌ Bad
// Loop through documents
for (const doc of documents) {
  // Process document
}

// ✅ Good
// Reindex documents to improve search performance
// after bulk import operation
for (const doc of documents) {
  await searchIndex.reindex(doc);
}
```

### 8. Performance Optimization

```typescript
// ✅ Good: Debounce user input
import { debounce } from 'lodash';

const debouncedSearch = useMemo(
  () => debounce((term: string) => {
    searchDocuments(term);
  }, 300),
  []
);

// ✅ Good: Lazy loading
const HeavyComponent = lazy(() => import('./HeavyComponent'));

// ✅ Good: Virtual scrolling for large lists
import { FixedSizeList } from 'react-window';

<FixedSizeList
  height={600}
  itemCount={documents.length}
  itemSize={50}
  width="100%"
>
  {({ index, style }) => (
    <DocumentRow document={documents[index]} style={style} />
  )}
</FixedSizeList>

// ✅ Good: Code splitting
const routes = [
  {
    path: '/documents',
    component: lazy(() => import('@modules/documents')),
  },
  {
    path: '/audits',
    component: lazy(() => import('@modules/audits')),
  },
];
```

## Testing Standards

```typescript
// Unit test example
describe('DocumentService', () => {
  let service: DocumentService;

  beforeEach(() => {
    service = new DocumentService();
  });

  describe('getDocument', () => {
    it('should return document when it exists', async () => {
      // Arrange
      const mockDocument: Document = {
        id: '123',
        title: 'Test Doc',
        // ... other fields
      };
      jest.spyOn(db.documents, 'get').mockResolvedValue(mockDocument);

      // Act
      const result = await service.getDocument('123');

      // Assert
      expect(result).toEqual(mockDocument);
      expect(db.documents.get).toHaveBeenCalledWith('123');
    });

    it('should throw NotFoundError when document does not exist', async () => {
      // Arrange
      jest.spyOn(db.documents, 'get').mockResolvedValue(null);

      // Act & Assert
      await expect(service.getDocument('999')).rejects.toThrow(NotFoundError);
    });
  });
});
```

## Code Review Checklist

- [ ] Follows TypeScript best practices
- [ ] Proper error handling
- [ ] Appropriate comments and documentation
- [ ] No console.log (use logger)
- [ ] No magic numbers (use constants)
- [ ] Tests included
- [ ] Performance considered
- [ ] Security vulnerabilities addressed
- [ ] Accessibility standards met
- [ ] Code is DRY (Don't Repeat Yourself)
- [ ] Functions are small and focused
- [ ] Names are clear and descriptive

## Additional Resources

- [TypeScript Handbook](https://www.typescriptlang.org/docs/handbook/intro.html)
- [React Best Practices](https://react.dev/learn)
- [Clean Code by Robert Martin](https://www.amazon.com/Clean-Code-Handbook-Software-Craftsmanship/dp/0132350882)
