# 🚀 Quick Implementation Guide

This guide will help you reorganize your Pharmaceutical QMS project step-by-step.

## Phase 1: Backup & Setup (Day 1)

### 1. Create Backup Branch
```bash
# Create a backup of current state
git checkout -b backup-before-reorganization
git push origin backup-before-reorganization

# Return to main
git checkout main
```

### 2. Create Development Branch
```bash
# Create reorganization branch
git checkout -b reorganize-project-structure
```

### 3. Add New Documentation
```bash
# Copy all the new documentation files to your repository
# - README.md
# - PROJECT_STRUCTURE.md
# - CODE_ORGANIZATION.md
# - PROJECT_MANAGEMENT.md
# - PHARMACEUTICAL_BEST_PRACTICES.md
# - CONTRIBUTING.md
# - .gitignore

# Add to git
git add README.md PROJECT_STRUCTURE.md CODE_ORGANIZATION.md
git add PROJECT_MANAGEMENT.md PHARMACEUTICAL_BEST_PRACTICES.md
git add CONTRIBUTING.md .gitignore
git commit -m "docs: add comprehensive project documentation"
```

## Phase 2: Folder Structure (Day 2-3)

### 1. Create New Directory Structure
```bash
# Create main directories
mkdir -p app/{core,modules,shared,styles}
mkdir -p public tests/{unit,integration,e2e,mocks,setup}
mkdir -p docs/{api,user-guide,technical,compliance,development}
mkdir -p scripts config

# Create core subdirectories
mkdir -p app/core/{auth,database,config}

# Create shared subdirectories
mkdir -p app/shared/{components,services,models,utils,constants,types,guards}

# Create module directories
mkdir -p app/modules/{documents,quality-events,audits,sops,training}
mkdir -p app/modules/{batch-records,materials,laboratory,compliance}
mkdir -p app/modules/{risk-management,analytics,settings}

# Create test directories
mkdir -p tests/{unit,integration,e2e}/{components,services,modules}

# Create docs subdirectories
mkdir -p docs/{api,user-guide,technical,compliance,development}
```

### 2. Create .gitkeep Files (to preserve empty directories)
```bash
find app tests docs -type d -empty -exec touch {}/.gitkeep \;
```

### 3. Commit Structure
```bash
git add .
git commit -m "chore: create new project directory structure"
```

## Phase 3: Move Existing Files (Day 4-5)

### 1. Analyze Current Files
```bash
# List current files
find . -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" | grep -v node_modules

# Categorize them:
# - Which are components?
# - Which are services?
# - Which are utilities?
# - Which belong to specific modules?
```

### 2. Move Files Systematically
```bash
# Example: Moving component files
git mv app/components/DocumentViewer.tsx app/shared/components/DocumentViewer.tsx
git mv app/components/Button.tsx app/shared/components/Button.tsx

# Example: Moving services
git mv app/services/documentService.ts app/modules/documents/services/document.service.ts

# Example: Moving utilities
git mv app/utils/dateUtils.ts app/shared/utils/date.utils.ts

# Commit after each logical group
git commit -m "refactor: reorganize component files"
```

### 3. Rename Files for Consistency
```bash
# Rename to follow naming conventions
git mv app/documentService.ts app/modules/documents/services/document.service.ts
git mv app/Document.ts app/modules/documents/models/document.model.ts
```

## Phase 4: Update Imports (Day 6-7)

### 1. Update tsconfig.json
```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@app/*": ["app/*"],
      "@core/*": ["app/core/*"],
      "@modules/*": ["app/modules/*"],
      "@shared/*": ["app/shared/*"],
      "@assets/*": ["assets/*"],
      "@tests/*": ["tests/*"]
    }
  }
}
```

### 2. Update All Import Statements
```bash
# Use find and replace in your editor
# Old: import { DocumentService } from '../services/documentService';
# New: import { documentService } from '@modules/documents/services';

# Or use a script:
# find app -name "*.ts" -o -name "*.tsx" | xargs sed -i 's/from "..\/services/from "@shared\/services/g'
```

### 3. Test and Fix Imports
```bash
# Try to build
npm run build

# Fix any broken imports
# Update import paths one by one
```

### 4. Commit Changes
```bash
git add .
git commit -m "refactor: update import paths to use new structure"
```

## Phase 5: Create Module Index Files (Day 8)

### 1. Create Barrel Exports
```bash
# For each module, create index.ts
# app/modules/documents/index.ts
```

Example content:
```typescript
// app/modules/documents/index.ts
export * from './components';
export * from './services';
export * from './models';
```

### 2. Commit
```bash
git add app/modules/*/index.ts
git commit -m "feat: add barrel exports for all modules"
```

## Phase 6: Setup GitHub (Day 9)

### 1. Create Issue Templates
```bash
# Create .github directory
mkdir -p .github/{workflows,ISSUE_TEMPLATE}

# Copy issue templates
cp ISSUE_TEMPLATE_BUG.md .github/ISSUE_TEMPLATE/bug_report.md
cp ISSUE_TEMPLATE_FEATURE.md .github/ISSUE_TEMPLATE/feature_request.md

# Create pull request template
cat > .github/PULL_REQUEST_TEMPLATE.md << 'EOF'
## Description
Brief description of changes.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Refactoring
- [ ] Documentation

## Related Issues
Fixes #

## Testing
- [ ] Tests added/updated
- [ ] All tests passing

## Compliance
- [ ] GMP requirements considered
- [ ] Audit trail updated
EOF
```

### 2. Setup Labels
```bash
# Go to GitHub repository
# Settings > Labels
# Create labels as documented in PROJECT_MANAGEMENT.md
```

### 3. Create Project Board
```bash
# Go to GitHub repository
# Projects > New Project
# Create Kanban board with columns:
# - Backlog
# - To Do
# - In Progress
# - In Review
# - Done
```

## Phase 7: Add CI/CD (Day 10)

### 1. Create GitHub Actions Workflow
```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run lint
      - run: npm run test
      - run: npm run build
```

### 2. Commit
```bash
git add .github/workflows/ci.yml
git commit -m "ci: add GitHub Actions workflow"
```

## Phase 8: Update package.json (Day 10)

### 1. Add Scripts
```json
{
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview",
    "test": "jest",
    "test:watch": "jest --watch",
    "test:coverage": "jest --coverage",
    "lint": "eslint . --ext .ts,.tsx",
    "lint:fix": "eslint . --ext .ts,.tsx --fix",
    "format": "prettier --write \"**/*.{ts,tsx,css,md}\"",
    "type-check": "tsc --noEmit"
  }
}
```

### 2. Commit
```bash
git add package.json
git commit -m "chore: update npm scripts"
```

## Phase 9: Testing & Validation (Day 11-12)

### 1. Test Application
```bash
# Start development server
npm run dev

# Test all features:
# - Can you navigate?
# - Do imports work?
# - Are all features functional?
```

### 2. Fix Any Issues
```bash
# Fix broken imports
# Fix broken paths
# Fix any runtime errors
```

### 3. Run Full Test Suite
```bash
npm run lint
npm run test
npm run build
```

## Phase 10: Merge & Deploy (Day 13)

### 1. Create Pull Request
```bash
# Push your branch
git push origin reorganize-project-structure

# Go to GitHub
# Create Pull Request from reorganize-project-structure to main
# Use the PR template
# Add description of changes
```

### 2. Review & Test
- Review all changes
- Test on staging environment
- Get approval from team

### 3. Merge
```bash
# After approval, merge to main
# Use "Squash and merge" to keep history clean
```

### 4. Deploy
```bash
# Deploy to production
# Monitor for issues
```

## Phase 11: Post-Migration (Day 14+)

### 1. Update Documentation
- Ensure README is accurate
- Update any outdated docs
- Add migration notes to CHANGELOG.md

### 2. Team Training
- Walk team through new structure
- Explain new conventions
- Share PROJECT_STRUCTURE.md and CODE_ORGANIZATION.md

### 3. Monitor
- Watch for issues
- Gather feedback
- Make adjustments as needed

## Quick Reference Commands

### Daily Workflow
```bash
# Start working
git checkout -b feature/new-feature
npm run dev

# Before committing
npm run lint
npm run test
git add .
git commit -m "feat(module): description"

# Push and create PR
git push origin feature/new-feature
```

### Creating New Module
```bash
# Create module structure
MODULE_NAME="new-module"
mkdir -p app/modules/$MODULE_NAME/{components,services,models,validators,tests}

# Create index files
touch app/modules/$MODULE_NAME/index.ts
touch app/modules/$MODULE_NAME/README.md

# Create initial files
cat > app/modules/$MODULE_NAME/index.ts << EOF
export * from './components';
export * from './services';
export * from './models';
EOF
```

### Running Tests
```bash
# All tests
npm run test

# Watch mode
npm run test:watch

# Coverage
npm run test:coverage

# Specific module
npm run test -- modules/documents
```

## Troubleshooting

### Import Errors
```bash
# Problem: Cannot find module '@modules/...'
# Solution: Check tsconfig.json paths configuration

# Problem: Circular dependencies
# Solution: Review import chain, extract shared code
```

### Build Errors
```bash
# Problem: Type errors after reorganization
# Solution: Update type imports, check tsconfig.json

# Problem: Missing dependencies
# Solution: npm install
```

### Git Issues
```bash
# Problem: Too many changes to commit
# Solution: Use git add -p for selective staging

# Problem: Merge conflicts
# Solution: Resolve conflicts, test thoroughly
```

## Success Checklist

After reorganization, verify:
- [ ] All files in correct locations
- [ ] Naming conventions followed
- [ ] Imports updated and working
- [ ] Tests passing
- [ ] Build succeeds
- [ ] Documentation updated
- [ ] CI/CD pipeline working
- [ ] Team trained on new structure
- [ ] No broken features
- [ ] Performance maintained

## Next Steps

1. **Week 1**: Start with Phase 1-3 (backup, structure, move files)
2. **Week 2**: Complete Phase 4-6 (imports, exports, GitHub setup)
3. **Week 3**: Finish Phase 7-10 (CI/CD, testing, deployment)
4. **Week 4**: Polish and optimize

## Need Help?

- Review PROJECT_STRUCTURE.md for detailed structure
- Check CODE_ORGANIZATION.md for coding standards
- See CONTRIBUTING.md for contribution guidelines
- Ask questions in GitHub Discussions

---

**Take it one step at a time. Quality over speed!**
